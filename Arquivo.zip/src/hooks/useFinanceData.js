import { useState, useEffect, useCallback } from 'react';

const STORAGE_KEYS = {
  CATEGORIES: 'finance_categories',
  EXPENSES: 'finance_expenses',
  SETTINGS: 'finance_settings',
};

const DEFAULT_CATEGORIES = [
  { id: '1', name: 'Alimentação', color: '#4CAF50', limit: 800 },
  { id: '2', name: 'Transporte', color: '#2196F3', limit: 500 },
  { id: '3', name: 'Saúde', color: '#F44336', limit: 600 },
  { id: '4', name: 'Lazer', color: '#9C27B0', limit: 400 },
  { id: '5', name: 'Outros', color: '#FF9800', limit: 300 },
];

const DEFAULT_SETTINGS = {
  salary: 3000,
  totalLimit: 3000,
  alertThreshold: 80,
};

export function useFinanceData() {
  const [categories, setCategories] = useState([]);
  const [expenses, setExpenses] = useState([]);
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setIsLoading(true);
      const categoriesData = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
      const expensesData = localStorage.getItem(STORAGE_KEYS.EXPENSES);
      const settingsData = localStorage.getItem(STORAGE_KEYS.SETTINGS);

      if (categoriesData) {
        setCategories(JSON.parse(categoriesData));
      } else {
        setCategories(DEFAULT_CATEGORIES);
        localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(DEFAULT_CATEGORIES));
      }

      if (expensesData) {
        setExpenses(JSON.parse(expensesData));
      } else {
        setExpenses([]);
      }

      if (settingsData) {
        setSettings(JSON.parse(settingsData));
      } else {
        setSettings(DEFAULT_SETTINGS);
        localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(DEFAULT_SETTINGS));
      }
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const addExpense = useCallback(
    (categoryId, amount, description, date) => {
      const newExpense = {
        id: Date.now().toString(),
        categoryId,
        amount,
        description,
        date,
        createdAt: new Date().toISOString(),
      };

      const updatedExpenses = [...expenses, newExpense];
      setExpenses(updatedExpenses);
      localStorage.setItem(STORAGE_KEYS.EXPENSES, JSON.stringify(updatedExpenses));
    },
    [expenses]
  );

  const removeExpense = useCallback(
    (expenseId) => {
      const updatedExpenses = expenses.filter((e) => e.id !== expenseId);
      setExpenses(updatedExpenses);
      localStorage.setItem(STORAGE_KEYS.EXPENSES, JSON.stringify(updatedExpenses));
    },
    [expenses]
  );

  const updateSettings = useCallback(
    (newSettings) => {
      const updatedSettings = { ...settings, ...newSettings };
      setSettings(updatedSettings);
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(updatedSettings));
    },
    [settings]
  );

  const updateCategory = useCallback(
    (categoryId, updates) => {
      const updatedCategories = categories.map((cat) =>
        cat.id === categoryId ? { ...cat, ...updates } : cat
      );
      setCategories(updatedCategories);
      localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(updatedCategories));
    },
    [categories]
  );

  const calculateSummary = useCallback(() => {
    const categorySummaries = categories.map((category) => {
      const categoryExpenses = expenses.filter((e) => e.categoryId === category.id);
      const totalSpent = categoryExpenses.reduce((sum, e) => sum + e.amount, 0);
      const remaining = category.limit - totalSpent;
      const percentageUsed = (totalSpent / category.limit) * 100;
      const isAlertActive = percentageUsed >= settings.alertThreshold;

      return {
        ...category,
        totalSpent,
        remaining,
        percentageUsed,
        isAlertActive,
      };
    });

    const totalSpent = categorySummaries.reduce((sum, cat) => sum + cat.totalSpent, 0);
    const totalLimit = settings.totalLimit;
    const remaining = totalLimit - totalSpent;
    const percentageUsed = (totalSpent / totalLimit) * 100;

    return {
      totalSpent,
      totalLimit,
      remaining,
      percentageUsed,
      categories: categorySummaries,
      salary: settings.salary,
    };
  }, [categories, expenses, settings]);

  return {
    categories,
    expenses,
    settings,
    isLoading,
    addExpense,
    removeExpense,
    updateSettings,
    updateCategory,
    calculateSummary,
    reloadData: loadData,
  };
}

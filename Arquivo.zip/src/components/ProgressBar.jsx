export function ProgressBar({ percentage, color = '#FF8C00' }) {
  const clampedPercentage = Math.min(percentage, 100);
  
  return (
    <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
      <div
        className="h-full rounded-full transition-all duration-300"
        style={{
          width: `${clampedPercentage}%`,
          backgroundColor: color,
        }}
      />
    </div>
  );
}

import { useState } from 'react';
import { Plus, Settings, Edit2, Trash2 } from 'lucide-react';
import { CircularProgress } from '../components/CircularProgress';
import { ProgressBar } from '../components/ProgressBar';

export function Home({ data, onAddExpense, onRemoveExpense, onNavigate, onEditCategory }) {
  const summary = data.calculateSummary();
  const [expandedCategory, setExpandedCategory] = useState(null);

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4 flex justify-between items-center sticky top-0 z-10">
        <h1 className="text-2xl font-bold text-gray-900">Meu Controle Financeiro</h1>
        <button
          onClick={() => onNavigate('settings')}
          className="p-2 hover:bg-gray-100 rounded-lg transition"
        >
          <Settings size={24} className="text-gray-600" />
        </button>
      </div>

      {/* Main Content */}
      <div className="max-w-2xl mx-auto px-4 py-6 space-y-6">
        {/* Circular Progress */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
          <CircularProgress percentage={summary.percentageUsed}>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">
                {Math.round(summary.percentageUsed)}%
              </div>
            </div>
          </CircularProgress>
        </div>

        {/* Consumption Info */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
          <h2 className="text-gray-600 text-sm mb-3">Consumo do limite consolidado</h2>
          <ProgressBar percentage={summary.percentageUsed} />
          <p className="text-gray-600 text-sm mt-3">
            {formatCurrency(summary.totalSpent)} de {formatCurrency(summary.totalLimit)} consumidos no período.
          </p>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-200">
            <p className="text-gray-500 text-xs uppercase tracking-wider mb-2">Total Gasto</p>
            <p className="text-2xl font-bold text-primary">{formatCurrency(summary.totalSpent)}</p>
          </div>
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-200">
            <p className="text-gray-500 text-xs uppercase tracking-wider mb-2">Limite Total</p>
            <p className="text-2xl font-bold text-gray-900">{formatCurrency(summary.totalLimit)}</p>
          </div>
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-200">
            <p className="text-gray-500 text-xs uppercase tracking-wider mb-2">Restante</p>
            <p className="text-2xl font-bold text-success">{formatCurrency(summary.remaining)}</p>
          </div>
        </div>

        {/* Categories */}
        <div className="space-y-4">
          <h2 className="text-lg font-bold text-gray-900">Categorias</h2>
          {summary.categories.map((category) => (
            <div key={category.id} className="bg-white rounded-2xl p-4 shadow-sm border border-gray-200">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div
                    className="w-4 h-4 rounded-full"
                    style={{ backgroundColor: category.color }}
                  />
                  <div>
                    <h3 className="font-semibold text-gray-900">{category.name}</h3>
                    {category.isAlertActive && (
                      <span className="text-xs text-orange-600 font-semibold">Aviso em {Math.round(category.percentageUsed)}%</span>
                    )}
                  </div>
                </div>
                <button
                  onClick={() => onEditCategory(category.id)}
                  className="p-1 hover:bg-gray-100 rounded transition"
                >
                  <Edit2 size={18} className="text-gray-600" />
                </button>
              </div>

              <ProgressBar percentage={category.percentageUsed} color={category.color} />

              <div className="grid grid-cols-3 gap-2 mt-3 text-sm">
                <div>
                  <p className="text-gray-500 text-xs">Gasto</p>
                  <p className="font-semibold text-primary">{formatCurrency(category.totalSpent)}</p>
                </div>
                <div>
                  <p className="text-gray-500 text-xs">Limite</p>
                  <p className="font-semibold text-gray-900">{formatCurrency(category.limit)}</p>
                </div>
                <div>
                  <p className="text-gray-500 text-xs">Restante</p>
                  <p className="font-semibold text-success">{formatCurrency(category.remaining)}</p>
                </div>
              </div>

              {/* Expenses List */}
              {data.expenses.filter(e => e.categoryId === category.id).length > 0 && (
                <div className="mt-4 pt-4 border-t border-gray-200">
                  <button
                    onClick={() => setExpandedCategory(expandedCategory === category.id ? null : category.id)}
                    className="text-sm text-primary font-semibold hover:underline"
                  >
                    {expandedCategory === category.id ? 'Ocultar' : 'Ver'} despesas ({data.expenses.filter(e => e.categoryId === category.id).length})
                  </button>

                  {expandedCategory === category.id && (
                    <div className="mt-3 space-y-2">
                      {data.expenses
                        .filter(e => e.categoryId === category.id)
                        .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
                        .map(expense => (
                          <div key={expense.id} className="flex justify-between items-center bg-gray-50 p-3 rounded-lg">
                            <div>
                              <p className="text-sm font-medium text-gray-900">{expense.description}</p>
                              <p className="text-xs text-gray-500">{new Date(expense.date).toLocaleDateString('pt-BR')}</p>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="font-semibold text-gray-900">{formatCurrency(expense.amount)}</span>
                              <button
                                onClick={() => onRemoveExpense(expense.id)}
                                className="p-1 hover:bg-red-100 rounded transition"
                              >
                                <Trash2 size={16} className="text-error" />
                              </button>
                            </div>
                          </div>
                        ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Floating Action Button */}
      <button
        onClick={() => onNavigate('add-expense')}
        className="fixed bottom-8 right-8 bg-primary text-white rounded-full p-4 shadow-lg hover:bg-orange-600 transition transform hover:scale-110"
      >
        <Plus size={28} />
      </button>
    </div>
  );
}

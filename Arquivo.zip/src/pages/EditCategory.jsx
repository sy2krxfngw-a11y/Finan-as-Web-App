import { useState, useEffect } from 'react';
import { ArrowLeft } from 'lucide-react';

const AVAILABLE_COLORS = [
  '#4CAF50', '#2196F3', '#F44336', '#FF9800', '#9C27B0',
  '#00BCD4', '#E91E63', '#FFC107', '#795548', '#607D8B',
];

export function EditCategory({ categoryId, categories, onUpdateCategory, onNavigate }) {
  const category = categories.find(c => c.id === categoryId);
  const [name, setName] = useState('');
  const [color, setColor] = useState('#4CAF50');
  const [limit, setLimit] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (category) {
      setName(category.name);
      setColor(category.color);
      setLimit(category.limit.toString());
    }
  }, [category]);

  if (!category) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-gray-600">Categoria não encontrada</p>
      </div>
    );
  }

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!name.trim()) {
      alert('Por favor, insira um nome para a categoria');
      return;
    }

    const limitNum = parseFloat(limit);
    if (isNaN(limitNum) || limitNum <= 0) {
      alert('Por favor, insira um limite válido');
      return;
    }

    try {
      setIsSaving(true);
      onUpdateCategory(category.id, {
        name: name.trim(),
        color,
        limit: limitNum,
      });
      alert('Categoria atualizada com sucesso!');
      onNavigate('home');
    } catch (error) {
      alert('Erro ao atualizar categoria');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4 flex items-center gap-4 sticky top-0 z-10">
        <button
          onClick={() => onNavigate('home')}
          className="p-2 hover:bg-gray-100 rounded-lg transition"
        >
          <ArrowLeft size={24} className="text-gray-600" />
        </button>
        <h1 className="text-2xl font-bold text-gray-900">Editar Categoria</h1>
      </div>

      {/* Form */}
      <div className="max-w-2xl mx-auto px-4 py-6">
        <form onSubmit={handleSubmit} className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200 space-y-6">
          {/* Name */}
          <div>
            <label className="text-sm font-semibold text-gray-700 uppercase tracking-wider block mb-3">
              Nome da Categoria
            </label>
            <input
              type="text"
              placeholder="Ex: Alimentação"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary"
              required
            />
          </div>

          {/* Color Picker */}
          <div>
            <label className="text-sm font-semibold text-gray-700 uppercase tracking-wider block mb-3">
              Cor da Categoria
            </label>
            <div className="flex flex-wrap gap-3">
              {AVAILABLE_COLORS.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setColor(c)}
                  className={`w-12 h-12 rounded-full border-2 transition ${
                    color === c ? 'border-gray-900' : 'border-transparent'
                  }`}
                  style={{ backgroundColor: c }}
                  title={c}
                />
              ))}
            </div>
          </div>

          {/* Limit */}
          <div>
            <label className="text-sm font-semibold text-gray-700 uppercase tracking-wider block mb-3">
              Limite Mensal (R$)
            </label>
            <input
              type="number"
              step="0.01"
              min="0"
              placeholder="0,00"
              value={limit}
              onChange={(e) => setLimit(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary"
              required
            />
          </div>

          {/* Preview */}
          <div className="bg-gray-50 rounded-2xl p-4 border border-gray-200">
            <p className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-3">Visualização</p>
            <div className="flex items-center gap-3">
              <div
                className="w-6 h-6 rounded-full"
                style={{ backgroundColor: color }}
              />
              <div>
                <p className="font-semibold text-gray-900">{name || 'Categoria'}</p>
                <p className="text-sm text-gray-600">
                  Limite: R$ {parseFloat(limit || 0).toFixed(2)}
                </p>
              </div>
            </div>
          </div>

          {/* Buttons */}
          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={() => onNavigate('home')}
              className="flex-1 px-6 py-3 border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="flex-1 px-6 py-3 bg-primary text-white rounded-xl font-semibold hover:bg-orange-600 transition disabled:opacity-50"
            >
              {isSaving ? 'Salvando...' : 'Salvar'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

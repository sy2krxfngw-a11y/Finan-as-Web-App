import { useState } from 'react';
import { ArrowLeft } from 'lucide-react';

export function AddExpense({ categories, onAddExpense, onNavigate }) {
  const [categoryId, setCategoryId] = useState(categories[0]?.id || '');
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [isSaving, setIsSaving] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();

    const amountNum = parseFloat(amount);
    if (!categoryId || isNaN(amountNum) || amountNum <= 0) {
      alert('Por favor, preencha todos os campos corretamente');
      return;
    }

    try {
      setIsSaving(true);
      onAddExpense(categoryId, amountNum, description || 'Sem descrição', date);
      alert('Gasto adicionado com sucesso!');
      onNavigate('home');
    } catch (error) {
      alert('Erro ao adicionar gasto');
    } finally {
      setIsSaving(false);
    }
  };

  const selectedCategory = categories.find(c => c.id === categoryId);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4 flex items-center gap-4 sticky top-0 z-10">
        <button
          onClick={() => onNavigate('home')}
          className="p-2 hover:bg-gray-100 rounded-lg transition"
        >
          <ArrowLeft size={24} className="text-gray-600" />
        </button>
        <h1 className="text-2xl font-bold text-gray-900">Adicionar Gasto</h1>
      </div>

      {/* Form */}
      <div className="max-w-2xl mx-auto px-4 py-6">
        <form onSubmit={handleSubmit} className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200 space-y-6">
          {/* Category Selection */}
          <div>
            <label className="text-sm font-semibold text-gray-700 uppercase tracking-wider block mb-3">
              Categoria
            </label>
            <select
              value={categoryId}
              onChange={(e) => setCategoryId(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary"
            >
              {categories.map(cat => (
                <option key={cat.id} value={cat.id}>
                  {cat.name}
                </option>
              ))}
            </select>
            {selectedCategory && (
              <div className="mt-3 flex items-center gap-2">
                <div
                  className="w-4 h-4 rounded-full"
                  style={{ backgroundColor: selectedCategory.color }}
                />
                <span className="text-sm text-gray-600">
                  Limite: R$ {selectedCategory.limit.toFixed(2)}
                </span>
              </div>
            )}
          </div>

          {/* Amount */}
          <div>
            <label className="text-sm font-semibold text-gray-700 uppercase tracking-wider block mb-3">
              Valor (R$)
            </label>
            <input
              type="number"
              step="0.01"
              min="0"
              placeholder="0,00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary"
              required
            />
          </div>

          {/* Description */}
          <div>
            <label className="text-sm font-semibold text-gray-700 uppercase tracking-wider block mb-3">
              Descrição (Opcional)
            </label>
            <input
              type="text"
              placeholder="Ex: Almoço no restaurante"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>

          {/* Date */}
          <div>
            <label className="text-sm font-semibold text-gray-700 uppercase tracking-wider block mb-3">
              Data
            </label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary"
              required
            />
          </div>

          {/* Buttons */}
          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={() => onNavigate('home')}
              className="flex-1 px-6 py-3 border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="flex-1 px-6 py-3 bg-primary text-white rounded-xl font-semibold hover:bg-orange-600 transition disabled:opacity-50"
            >
              {isSaving ? 'Salvando...' : 'Adicionar Gasto'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

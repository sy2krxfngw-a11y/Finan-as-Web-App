import { useState, useEffect } from 'react';
import { ArrowLeft } from 'lucide-react';

export function Settings({ settings, onUpdateSettings, onNavigate }) {
  const [salary, setSalary] = useState('');
  const [totalLimit, setTotalLimit] = useState('');
  const [alertThreshold, setAlertThreshold] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [hasInitialized, setHasInitialized] = useState(false);

  useEffect(() => {
    if (!hasInitialized && settings) {
      setSalary(settings.salary.toString());
      setTotalLimit(settings.totalLimit.toString());
      setAlertThreshold(settings.alertThreshold.toString());
      setHasInitialized(true);
    }
  }, [settings, hasInitialized]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    const salaryNum = parseFloat(salary);
    const limitNum = parseFloat(totalLimit);
    const thresholdNum = parseFloat(alertThreshold);

    if (isNaN(salaryNum) || isNaN(limitNum) || isNaN(thresholdNum)) {
      alert('Por favor, insira valores válidos');
      return;
    }

    if (salaryNum <= 0 || limitNum <= 0) {
      alert('Salário e limite devem ser maiores que zero');
      return;
    }

    if (thresholdNum < 0 || thresholdNum > 100) {
      alert('O limite de alerta deve estar entre 0 e 100%');
      return;
    }

    try {
      setIsSaving(true);
      onUpdateSettings({
        salary: salaryNum,
        totalLimit: limitNum,
        alertThreshold: thresholdNum,
      });
      alert('Configurações salvas com sucesso!');
      setHasInitialized(false);
    } catch (error) {
      alert('Erro ao salvar configurações');
    } finally {
      setIsSaving(false);
    }
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4 flex items-center gap-4 sticky top-0 z-10">
        <button
          onClick={() => onNavigate('home')}
          className="p-2 hover:bg-gray-100 rounded-lg transition"
        >
          <ArrowLeft size={24} className="text-gray-600" />
        </button>
        <h1 className="text-2xl font-bold text-gray-900">Configurações</h1>
      </div>

      {/* Form */}
      <div className="max-w-2xl mx-auto px-4 py-6">
        <form onSubmit={handleSubmit} className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200 space-y-6">
          <h2 className="text-lg font-bold text-gray-900">Configurações Financeiras</h2>

          {/* Salary */}
          <div>
            <label className="text-sm font-semibold text-gray-700 uppercase tracking-wider block mb-3">
              Salário Mensal (R$)
            </label>
            <input
              type="number"
              step="0.01"
              min="0"
              placeholder="0,00"
              value={salary}
              onChange={(e) => setSalary(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary"
              required
            />
            <p className="text-xs text-gray-600 mt-2">
              Valor: {formatCurrency(parseFloat(salary) || 0)}
            </p>
          </div>

          {/* Total Limit */}
          <div>
            <label className="text-sm font-semibold text-gray-700 uppercase tracking-wider block mb-3">
              Limite Total de Gastos (R$)
            </label>
            <input
              type="number"
              step="0.01"
              min="0"
              placeholder="0,00"
              value={totalLimit}
              onChange={(e) => setTotalLimit(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary"
              required
            />
            <p className="text-xs text-gray-600 mt-2">
              Valor: {formatCurrency(parseFloat(totalLimit) || 0)}
            </p>
          </div>

          {/* Alert Threshold */}
          <div>
            <label className="text-sm font-semibold text-gray-700 uppercase tracking-wider block mb-3">
              Limite de Alerta (%)
            </label>
            <input
              type="number"
              step="1"
              min="0"
              max="100"
              placeholder="80"
              value={alertThreshold}
              onChange={(e) => setAlertThreshold(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary"
              required
            />
            <p className="text-xs text-gray-600 mt-2">
              Você será alertado quando atingir {alertThreshold}% do limite
            </p>
          </div>

          {/* Info Box */}
          <div className="bg-blue-50 rounded-2xl p-4 border border-blue-200">
            <p className="text-sm font-semibold text-blue-900 mb-1">💡 Dica</p>
            <p className="text-sm text-blue-800">
              Defina o limite total de gastos igual ao seu salário para controlar melhor seus gastos mensais.
            </p>
          </div>

          {/* Buttons */}
          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={() => onNavigate('home')}
              className="flex-1 px-6 py-3 border border-gray-300 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="flex-1 px-6 py-3 bg-primary text-white rounded-xl font-semibold hover:bg-orange-600 transition disabled:opacity-50"
            >
              {isSaving ? 'Salvando...' : 'Salvar'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

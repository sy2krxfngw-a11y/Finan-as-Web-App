import { useState } from 'react';
import { useFinanceData } from './hooks/useFinanceData';
import { Home } from './pages/Home';
import { AddExpense } from './pages/AddExpense';
import { EditCategory } from './pages/EditCategory';
import { Settings } from './pages/Settings';

function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [editingCategoryId, setEditingCategoryId] = useState(null);
  const data = useFinanceData();

  const handleNavigate = (page, categoryId = null) => {
    setCurrentPage(page);
    if (categoryId) {
      setEditingCategoryId(categoryId);
    }
  };

  const handleAddExpense = (categoryId, amount, description, date) => {
    data.addExpense(categoryId, amount, description, date);
  };

  const handleRemoveExpense = (expenseId) => {
    if (window.confirm('Tem certeza que deseja remover este gasto?')) {
      data.removeExpense(expenseId);
    }
  };

  const handleUpdateSettings = (newSettings) => {
    data.updateSettings(newSettings);
  };

  const handleEditCategory = (categoryId) => {
    handleNavigate('edit-category', categoryId);
  };

  const handleUpdateCategory = (categoryId, updates) => {
    data.updateCategory(categoryId, updates);
  };

  if (data.isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
          <p className="mt-4 text-gray-600">Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {currentPage === 'home' && (
        <Home
          data={data}
          onAddExpense={handleAddExpense}
          onRemoveExpense={handleRemoveExpense}
          onNavigate={handleNavigate}
          onEditCategory={handleEditCategory}
        />
      )}
      {currentPage === 'add-expense' && (
        <AddExpense
          categories={data.categories}
          onAddExpense={handleAddExpense}
          onNavigate={handleNavigate}
        />
      )}
      {currentPage === 'edit-category' && (
        <EditCategory
          categoryId={editingCategoryId}
          categories={data.categories}
          onUpdateCategory={handleUpdateCategory}
          onNavigate={handleNavigate}
        />
      )}
      {currentPage === 'settings' && (
        <Settings
          settings={data.settings}
          onUpdateSettings={handleUpdateSettings}
          onNavigate={handleNavigate}
        />
      )}
    </div>
  );
}

export default App;
